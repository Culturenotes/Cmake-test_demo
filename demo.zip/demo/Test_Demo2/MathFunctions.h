#ifdef __cplusplus
extern "C"{
#endif
double power(double base, int exponent);
#ifdef __cplusplus
}
#endif
